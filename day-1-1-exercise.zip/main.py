#Write your code below this line 👇
print(
    "Day 1 - Python Print Function \nThe Function is declared like this: \nprint('what to print')"
)
